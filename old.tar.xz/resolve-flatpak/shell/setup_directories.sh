#!/bin/bash
mkdir -p /app/share/metainfo
chmod 755 /app/share/metainfo