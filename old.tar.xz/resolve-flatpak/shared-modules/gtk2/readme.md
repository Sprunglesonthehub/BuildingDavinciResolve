This directory contains two manifests:

- `gtk2.json`

  This contains a build of GTK2, the ibus input module, and the Adwaita and HighContrast themes.

- `gtk2-common-themes.json`

  This contains a collection of commonly used GTK2 themes that users might have. This is optional as it does build a few things.
  Without the matching theme the build of GTK2 here will always default to Adwaita.
